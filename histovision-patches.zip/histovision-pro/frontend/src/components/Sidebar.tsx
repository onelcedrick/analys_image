import { useCallback, useEffect, useState } from "react";
import type { RefObject } from "react";
import { DEMOS, KIND_META, type DemoImage } from "../data/demos";
import { Btn, Card, IconDrop, IconUpload, IconDownload } from "./ui";
import { imageDataToDataURL, downloadPNG, type ImgSlot } from "../lib/imaging";
import { listImages, type ImageMeta } from "../lib/apiClient";
import { absUrl } from "../lib/apiClient";

type Role = "target" | "palette";

export default function Sidebar({
  target,
  palette,
  fileTargetRef,
  filePaletteRef,
  loadDemo,
  serverUp,
  onSelectServerImage,
}: {
  target: ImgSlot | null;
  palette: ImgSlot | null;
  fileTargetRef: RefObject<HTMLInputElement | null>;
  filePaletteRef: RefObject<HTMLInputElement | null>;
  loadDemo: (d: DemoImage, role: Role) => void;
  serverUp: boolean;
  onSelectServerImage?: (meta: ImageMeta, role: Role) => void;
}) {
  const [library, setLibrary] = useState<ImageMeta[]>([]);
  const [loadingLib, setLoadingLib] = useState(false);

  const refreshLibrary = useCallback(async () => {
    if (!serverUp) {
      setLibrary([]);
      return;
    }
    setLoadingLib(true);
    try {
      const { images } = await listImages();
      setLibrary(images);
    } catch {
      setLibrary([]);
    } finally {
      setLoadingLib(false);
    }
  }, [serverUp]);

  useEffect(() => {
    refreshLibrary();
    if (!serverUp) return;
    const id = window.setInterval(refreshLibrary, 8000);
    return () => clearInterval(id);
  }, [refreshLibrary, serverUp]);

  // Expose refresh for parent after upload
  useEffect(() => {
    (window as unknown as { __hvRefreshLib?: () => void }).__hvRefreshLib = refreshLibrary;
    return () => {
      delete (window as unknown as { __hvRefreshLib?: () => void }).__hvRefreshLib;
    };
  }, [refreshLibrary]);

  return (
    <aside className="hidden w-[240px] shrink-0 lg:block">
      <div className="sticky top-[78px] max-h-[calc(100vh-90px)] space-y-4 overflow-y-auto pb-6 pr-1">
        {/* Prévisualisations */}
        <Card className="p-3">
          <div className="mb-2 font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-faint">
            Prévisualisations
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            <SlotPreview
              label="CIBLE"
              slot={target}
              tone="amber"
              onChange={() => fileTargetRef.current?.click()}
              onDownload={() => target && downloadPNG(target.data, `cible-${target.name}.png`)}
            />
            <SlotPreview
              label="PALETTE"
              slot={palette}
              tone="rose"
              onChange={() => filePaletteRef.current?.click()}
              onDownload={() => palette && downloadPNG(palette.data, `palette-${palette.name}.png`)}
            />
          </div>
        </Card>

        {/* Banque démo (légère, locale) */}
        <div>
          <div className="mb-2 flex items-center justify-between">
            <span className="font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-faint">
              Banque d'images
            </span>
            <span className="font-mono text-[9px] text-faint">{DEMOS.length}</span>
          </div>
          <div className="space-y-2">
            {DEMOS.map((d) => {
              const meta = KIND_META[d.kind];
              const isTarget = d.label === (target?.name ?? "");
              const isPalette = d.label === (palette?.name ?? "");
              return (
                <DemoCard
                  key={d.id}
                  d={d}
                  meta={meta}
                  isTarget={isTarget}
                  isPalette={isPalette}
                  onTarget={() => loadDemo(d, "target")}
                  onPalette={() => loadDemo(d, "palette")}
                />
              );
            })}
          </div>
        </div>

        {/* Bibliothèque serveur (persistée SQLite) */}
        {serverUp && (
          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-faint">
                Mes imports
              </span>
              <button
                type="button"
                onClick={refreshLibrary}
                className="font-mono text-[9px] text-teal hover:underline"
              >
                {loadingLib ? "…" : "rafraîchir"}
              </button>
            </div>
            {library.length === 0 ? (
              <p className="rounded-lg border border-dashed border-line px-2 py-3 text-center text-[10.5px] text-faint">
                Aucun upload encore.
                <br />
                Importez une image ci-dessous — elle sera stockée en base.
              </p>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                {library.slice(0, 12).map((img) => (
                  <button
                    key={img.id}
                    type="button"
                    title={`${img.width}×${img.height} — clic = cible`}
                    onClick={() => onSelectServerImage?.(img, "target")}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      onSelectServerImage?.(img, "palette");
                    }}
                    className="group overflow-hidden rounded-lg border border-line transition-all hover:border-amber/50"
                  >
                    <img
                      src={absUrl(img.thumb_url)}
                      alt={img.id}
                      className="h-16 w-full object-cover"
                      loading="lazy"
                    />
                    <div className="truncate bg-panel px-1.5 py-1 font-mono text-[8.5px] text-faint">
                      {img.width}×{img.height}
                    </div>
                  </button>
                ))}
              </div>
            )}
            <p className="mt-1.5 text-[9.5px] text-faint">Clic = cible · clic droit = palette</p>
          </div>
        )}

        {/* Import */}
        <div className="space-y-2">
          <Btn variant="teal" className="w-full" onClick={() => fileTargetRef.current?.click()}>
            <IconUpload /> Importer une cible
          </Btn>
          <Btn variant="ghost" className="w-full" onClick={() => filePaletteRef.current?.click()}>
            <IconDrop /> Importer une palette
          </Btn>
          <p className="text-[10.5px] leading-relaxed text-faint">
            JPG/PNG · max 1000 px · stocké en SQLite + disque pour le déploiement.
          </p>
        </div>

        {/* Slots */}
        <Card className="p-3">
          <div className="mb-2 font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-faint">
            Slots actifs
          </div>
          <div className="flex items-center justify-between gap-2 py-1">
            <span className="font-mono text-[9.5px] font-bold tracking-wider text-amber">CIBLE</span>
            <span className="truncate text-[11px] text-sub">{target?.name ?? "—"}</span>
          </div>
          <div className="flex items-center justify-between gap-2 py-1">
            <span className="font-mono text-[9.5px] font-bold tracking-wider text-rose">PALETTE</span>
            <span className="truncate text-[11px] text-sub">{palette?.name ?? "—"}</span>
          </div>
        </Card>
      </div>
    </aside>
  );
}

function SlotPreview({
  label,
  slot,
  tone,
  onChange,
  onDownload,
}: {
  label: string;
  slot: ImgSlot | null;
  tone: "amber" | "rose";
  onChange: () => void;
  onDownload: () => void;
}) {
  return (
    <div className="space-y-1.5">
      <div className={`font-mono text-[10px] ${tone === "amber" ? "text-amber" : "text-rose"}`}>{label}</div>
      {slot ? (
        <img
          src={imageDataToDataURL(slot.data)}
          alt={slot.name}
          className="h-[72px] w-full rounded-md border border-line object-cover"
        />
      ) : (
        <div className="flex h-[72px] w-full items-center justify-center rounded-md bg-panel2/40 text-[10px] text-faint">
          Aucune
        </div>
      )}
      <div className="flex gap-1">
        <Btn variant="ghost" className="flex-1 !px-1.5 !py-1 text-[10px]" onClick={onChange}>
          Changer
        </Btn>
        <Btn variant="ghost" className="!px-1.5 !py-1" disabled={!slot} onClick={onDownload}>
          <IconDownload />
        </Btn>
      </div>
    </div>
  );
}

function DemoCard({
  d,
  meta,
  isTarget,
  isPalette,
  onTarget,
  onPalette,
}: {
  d: DemoImage;
  meta: { label: string; cls: string; dot: string };
  isTarget: boolean;
  isPalette: boolean;
  onTarget: () => void;
  onPalette: () => void;
}) {
  return (
    <div
      className={`group relative overflow-hidden rounded-xl border transition-all duration-200 ${
        isTarget
          ? "border-amber/70 ring-2 ring-amber/20"
          : isPalette
            ? "border-rose/60 ring-2 ring-rose/15"
            : "border-line hover:border-line2"
      }`}
    >
      <button type="button" onClick={onTarget} className="block w-full text-left" title="Définir comme cible">
        <img
          src={d.url}
          alt={d.label}
          className="h-[70px] w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
          loading="lazy"
        />
        <div className="bg-panel px-2 py-1.5">
          <div className="flex items-center justify-between gap-1">
            <span className="truncate text-[11px] font-semibold text-ink">{d.label}</span>
            <span
              className={`flex shrink-0 items-center gap-1 rounded border px-1.5 py-px font-mono text-[8px] font-bold uppercase tracking-wider ${meta.cls}`}
            >
              <span className={`h-1 w-1 rounded-full ${meta.dot}`} />
              {meta.label}
            </span>
          </div>
        </div>
      </button>
      <div className="pointer-events-none absolute inset-x-0 top-0 flex justify-between p-1.5 opacity-0 transition-opacity group-hover:opacity-100">
        <span
          className="pointer-events-auto cursor-pointer rounded bg-bg0/85 px-1.5 py-0.5 font-mono text-[9px] font-bold text-amber ring-1 ring-amber/40"
          onClick={onTarget}
        >
          CIBLE
        </span>
        <span
          className="pointer-events-auto cursor-pointer rounded bg-bg0/85 px-1.5 py-0.5 font-mono text-[9px] font-bold text-rose ring-1 ring-rose/40"
          onClick={onPalette}
        >
          PALETTE
        </span>
      </div>
      {isTarget && (
        <span className="absolute left-1.5 top-1.5 rounded bg-amber px-1.5 py-px font-mono text-[8px] font-bold text-[#1a1204] group-hover:opacity-0">
          CIBLE
        </span>
      )}
      {isPalette && (
        <span className="absolute left-1.5 top-1.5 rounded bg-rose px-1.5 py-px font-mono text-[8px] font-bold text-white group-hover:opacity-0">
          PALETTE
        </span>
      )}
    </div>
  );
}
