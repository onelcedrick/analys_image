/* ------------------------------------------------------------------ */
/*  Client HTTP du backend HistoVision (FastAPI)                       */
/*                                                                     */
/*  En dev Vite, le proxy (vite.config) renvoie /api → :8000.          */
/*  On sonde d'abord l'origine relative, puis http://127.0.0.1:8000.  */
/* ------------------------------------------------------------------ */

const CANDIDATE_BASES = ["", "http://127.0.0.1:8000", "http://localhost:8000"];

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

let detectedBase: string | null | undefined = undefined;
let detectionPromise: Promise<string | null> | null = null;

async function probe(base: string): Promise<boolean> {
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 1500);
    const res = await fetch(`${base}/api/health`, {
      signal: ctrl.signal,
      cache: "no-store",
    });
    clearTimeout(timer);
    if (!res.ok) return false;
    // Vérifie que c'est bien notre API (évite un faux positif Vite/SPA)
    const ct = res.headers.get("content-type") || "";
    if (!ct.includes("application/json")) return false;
    const body = await res.json().catch(() => null);
    return !!body && (body.status === "ok" || body.status === "healthy");
  } catch {
    return false;
  }
}

/** Résout (une seule fois) la base de l'API joignable, ou null. */
export function detectApiBase(): Promise<string | null> {
  if (detectedBase !== undefined) return Promise.resolve(detectedBase);
  if (!detectionPromise) {
    detectionPromise = (async () => {
      for (const base of CANDIDATE_BASES) {
        if (await probe(base)) {
          detectedBase = base;
          return base;
        }
      }
      detectedBase = null;
      return null;
    })();
  }
  return detectionPromise;
}

/** Force une re-détection (après bascule de mode, par exemple). */
export function resetApiDetection(): void {
  detectedBase = undefined;
  detectionPromise = null;
}

export function currentBase(): string {
  return detectedBase ?? "";
}

/** Rend une URL absolue si l'API vit sur une autre origine. */
export function absUrl(path: string): string {
  const base = detectedBase ?? "";
  return path.startsWith("http") ? path : `${base}${path}`;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const base = await detectApiBase();
  if (base === null) throw new ApiError(0, "Backend injoignable — lancez uvicorn sur :8000");
  const res = await fetch(`${base}${path}`, init);
  if (!res.ok) {
    let detail = `HTTP ${res.status}`;
    try {
      const body = await res.json();
      if (body?.detail) detail = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
    } catch {
      /* ignore */
    }
    throw new ApiError(res.status, detail);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

/* ----------------------------- types API ---------------------------- */

export interface ImageMeta {
  id: string;
  width: number;
  height: number;
  channels: number;
  megapixels: number;
  thumb_url: string;
  image_url: string;
  created_at: number;
  filename?: string;
}

export interface ImageListOut {
  images: ImageMeta[];
}

export interface JobRefOut {
  job_id: string;
  status: string;
}

export interface JobOut {
  id: string;
  status: string;
  kind?: string;
  result_url?: string | null;
  metrics?: Record<string, unknown> | null;
  error?: string | null;
}

/* ----------------------------- endpoints ---------------------------- */

export async function listImages(): Promise<ImageListOut> {
  return request<ImageListOut>("/api/images");
}

export async function uploadImage(blob: Blob, filename = "upload.png"): Promise<ImageMeta> {
  const form = new FormData();
  // Force image/png (canvas toBlob) pour éviter content-type vide côté serveur
  const file = new File([blob], filename, { type: blob.type || "image/png" });
  form.append("file", file);
  return request<ImageMeta>("/api/images", { method: "POST", body: form });
}

export async function requestTransfer(body: {
  image_id: string;
  palette_id: string;
  strength?: number;
  skin_protect?: boolean;
  feather?: number;
}): Promise<JobRefOut> {
  return request<JobRefOut>("/api/transfer", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

export async function requestTexture(body: {
  image_id: string;
  clip?: number;
  smooth?: number;
  blend?: number;
}): Promise<JobRefOut> {
  return request<JobRefOut>("/api/texture", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

export async function requestForensic(body: { image_id: string }): Promise<JobRefOut> {
  return request<JobRefOut>("/api/forensic", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

export async function fetchJob(jobId: string): Promise<JobOut> {
  return request<JobOut>(`/api/jobs/${jobId}`);
}

export async function fetchResultBlob(resultUrl: string): Promise<Blob> {
  const res = await fetch(absUrl(resultUrl));
  if (!res.ok) throw new ApiError(res.status, `Résultat introuvable (${res.status})`);
  return res.blob();
}
