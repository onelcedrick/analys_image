import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 5173,
    proxy: {
      // Tout /api/* est renvoyé vers le backend FastAPI
      "/api": {
        target: "http://127.0.0.1:8000",
        changeOrigin: true,
      },
      // Fichiers résultats / vignettes servis par FastAPI
      "/storage": {
        target: "http://127.0.0.1:8000",
        changeOrigin: true,
      },
    },
  },
});
